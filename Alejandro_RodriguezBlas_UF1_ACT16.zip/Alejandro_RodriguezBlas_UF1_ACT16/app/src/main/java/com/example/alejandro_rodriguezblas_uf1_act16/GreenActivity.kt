package com.example.alejandro_rodriguezblas_uf1_act16

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class GreenActivity : AppCompatActivity() {

    lateinit var botonVolver: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_green)

        botonVolver = findViewById(R.id.button)

        botonVolver.setOnClickListener {
            val volverIntent = Intent(this, MainActivity::class.java)
            startActivity(volverIntent)
        }
    }
}