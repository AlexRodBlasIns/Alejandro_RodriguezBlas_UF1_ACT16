package com.example.alejandro_rodriguezblas_uf1_act16

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    lateinit var botonRojo: Button
    lateinit var botonVerde: Button
    lateinit var botonAzul: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        botonRojo = findViewById(R.id.button4)
        botonVerde = findViewById(R.id.button5)
        botonAzul = findViewById(R.id.button6)



        botonRojo.setOnClickListener {
            val sigRojo = Intent(this, RedActivity::class.java)
            startActivity(sigRojo)
        }
        botonVerde.setOnClickListener {
            val sigVerde = Intent(this, GreenActivity::class.java)
            startActivity(sigVerde)
        }
        botonAzul.setOnClickListener {
            val sigAzul = Intent(this, Azul::class.java)
            startActivity(sigAzul)
        }
    }
}